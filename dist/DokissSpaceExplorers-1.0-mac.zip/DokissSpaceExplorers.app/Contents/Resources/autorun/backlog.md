# Deep Space Explorers
- Rogue-like
- Lets go deeper in space

- Try no combat
Relaxing Game

## Specs
- Background 128x72 resize 1280x720
- Palette  

## equipage 
- planete natale

## achievment
- déposer un membre d'équipage sur sa planète natale
- retrouver un membre de la famille d'un membre de l'equipage
- trahison par membre équipage
- proposition de mariage membre equipage
- 10-50-100 jump

## Story
**done**

## Création perso / capitaine
**done**
- Nom joueur

## Generateur de planete
**done**
- planete
- station

**afficher skills**
**done**
- minage
- combat
- charisme

## scan planete
**done**
- $planeteFuel
- $planeteTechLevel=20
- $planeteHostileLevel=3
- danger/ usage de la violence sur la planete

## generateur quete planete/station
**done**
- assassiner en echange de fuel
- participer à rebellion armée en echange de fuel
- menacer pour obtenir fuel
- convaincre pour obtenir fuel
- echanger
- miner

## Perte fuel
**done**
- jump
- echec combat -> clonage

## Clone revelation
**done**
- vous vous réveillé intact et constaté la perte de 1 fuel

## generateur evenement espace
**todo**

## generateur de nom
**done**
- nom de planete
- nom de perso rencontre
- nom de ville / lieu
- nom d'animaux


## Score/compteurs d'exploits/ achievments
**done**
- sector visited
- fuel